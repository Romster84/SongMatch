package com.example.songmatch

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/**
 * Neural audio embedding via a YAMNet TFLite model placed at app/src/main/assets/yamnet.tflite.
 * Works with both variants: uses the 1024-d embedding output if the model has one,
 * otherwise falls back to the 521-class score vector. If the file is missing, [available] is false
 * and the app silently uses the hand-crafted features only.
 */
object Embedder {
    private const val PATCH = 15600      // 0.975 s @ 16 kHz
    private const val MAX_PATCHES = 40

    private var interp: Interpreter? = null
    private var outIdx = -1
    private var dim = 0
    private var inited = false
    var available = false
        private set

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        try {
            val fd = ctx.assets.openFd("yamnet.tflite")
            val map = FileInputStream(fd.fileDescriptor).channel
                .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
            val it = Interpreter(map, Interpreter.Options().setNumThreads(2))
            try { it.resizeInput(0, intArrayOf(PATCH)) } catch (_: Throwable) {}
            it.allocateTensors()
            var best = -1
            for (i in 0 until it.outputTensorCount) {
                val last = it.getOutputTensor(i).shape().lastOrNull() ?: 0
                if (last == 1024) { best = i; break }
                if (last == 521 && best < 0) best = i
            }
            if (best < 0) return
            interp = it
            outIdx = best
            dim = it.getOutputTensor(best).shape().last()
            available = true
        } catch (e: Throwable) {
            available = false
        }
    }

    private fun resample16k(x: FloatArray, sr: Int): FloatArray {
        if (sr == 16000) return x
        val ratio = sr / 16000.0
        val n = (x.size / ratio).toInt()
        return FloatArray(n) { i ->
            val a = (i * ratio).toInt()
            val b = min(x.size, max(a + 1, ((i + 1) * ratio).toInt()))
            var s = 0f
            for (k in a until b) s += x[k]
            s / (b - a)
        }
    }

    /** Mean embedding over the clip, or an empty array if the model isn't available. */
    fun embed(x: FloatArray, sr: Int): FloatArray {
        val it = interp ?: return FloatArray(0)
        val y = resample16k(x, sr)
        if (y.size < PATCH) return FloatArray(0)
        val total = (y.size - PATCH) / PATCH + 1
        val hop = if (total > MAX_PATCHES) (y.size - PATCH) / (MAX_PATCHES - 1) else PATCH

        val acc = DoubleArray(dim)
        var count = 0
        synchronized(this) {
            val inBuf = ByteBuffer.allocateDirect(PATCH * 4).order(ByteOrder.nativeOrder())
            val outTensor = it.getOutputTensor(outIdx)
            val outBuf = ByteBuffer.allocateDirect(outTensor.numBytes()).order(ByteOrder.nativeOrder())
            val n = outTensor.numBytes() / 4
            var off = 0
            while (off + PATCH <= y.size) {
                inBuf.clear()
                inBuf.asFloatBuffer().put(y, off, PATCH)
                inBuf.rewind()
                outBuf.clear()
                it.runForMultipleInputsOutputs(arrayOf<Any>(inBuf), mapOf<Int, Any>(outIdx to outBuf))
                outBuf.rewind()
                val fb = outBuf.asFloatBuffer()
                for (i in 0 until n) acc[i % dim] += fb.get(i).toDouble()
                count += max(1, n / dim)
                off += hop
            }
        }
        if (count == 0) return FloatArray(0)
        return FloatArray(dim) { (acc[it] / count).toFloat() }
    }
}
