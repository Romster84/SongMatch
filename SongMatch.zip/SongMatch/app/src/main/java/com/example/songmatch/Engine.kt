package com.example.songmatch

import kotlin.math.*

/** Weighted multi-feature similarity with seed averaging, like/dislike feedback and weight learning. */
class Engine(private val all: List<Track>) {

    companion object {
        val MOODS = listOf("پرانرژی", "آرام", "شاد", "غمگین", "تیره و شدید", "آکوستیک")
    }

    private fun stat(sel: (Features) -> Float): Pair<Float, Float> {
        val m = all.map { sel(it.f) }.average().toFloat()
        val v = all.map { (sel(it.f) - m).pow(2) }.average().toFloat()
        return m to max(sqrt(v), 1e-3f)
    }

    private val sE = stat { it.energy }
    private val sB = stat { it.brightness }
    private val sR = stat { it.rhythm }
    private val dims = all.firstOrNull()?.f?.timbre?.size ?: 0
    private val tm = FloatArray(dims) { d -> all.map { it.f.timbre[d] }.average().toFloat() }
    private val ts = FloatArray(dims) { d ->
        val v = all.map { (it.f.timbre[d] - tm[d]).pow(2) }.average().toFloat()
        max(sqrt(v), 1e-3f)
    }
    private val tz: Map<Long, FloatArray> = all.associate { t ->
        val v = FloatArray(dims) { (t.f.timbre[it] - tm[it]) / ts[it] }
        var n = 0f
        for (x in v) n += x * x
        n = max(sqrt(n), 1e-6f)
        t.id to FloatArray(dims) { v[it] / n }
    }

    private val edim = all.firstOrNull { it.f.embed.isNotEmpty() }?.f?.embed?.size ?: 0
    private val withE = if (edim == 0) emptyList() else all.filter { it.f.embed.size == edim }
    private val em = FloatArray(edim) { d -> withE.map { it.f.embed[d] }.average().toFloat() }
    private val ez: Map<Long, FloatArray> = withE.associate { t ->
        val v = FloatArray(edim) { t.f.embed[it] - em[it] }
        var n = 0f
        for (x in v) n += x * x
        n = max(sqrt(n), 1e-6f)
        t.id to FloatArray(edim) { v[it] / n }
    }

    private fun z(v: Float, st: Pair<Float, Float>) = (v - st.first) / st.second
    private fun sig(x: Float) = 1f / (1f + exp(-x))

    /** Rough, heuristic mood tags (not a trained mood model). */
    fun moodTags(t: Track): Set<String> {
        val zb = z(t.f.brightness, sB)
        val minor = t.f.key.endsWith("min")
        val arousal = 0.6f * sig(z(t.f.energy, sE)) + 0.4f * (t.f.bpm / 180f).coerceIn(0f, 1f)
        val valence = (if (minor) 0.35f else 0.65f) + 0.15f * sig(zb)
        val tags = HashSet<String>()
        if (arousal > 0.7f) tags.add("پرانرژی") else if (arousal < 0.4f) tags.add("آرام")
        if (valence > 0.65f) tags.add("شاد") else if (valence < 0.45f) tags.add("غمگین")
        if (minor && arousal > 0.5f) tags.add("تیره و شدید")
        if (sig(-zb) > 0.7f) tags.add("آکوستیک")
        return tags
    }

    // order: tempo, key, energy, bright, rhythm, timbre, vibe  (NaN = not available)
    private fun parts(s: Track, c: Track, b: Bias): FloatArray {
        val r = FloatArray(7) { Float.NaN }

        val d = log2(c.f.bpm) - (log2(s.f.bpm) + b.tempo * 0.3f)
        val m = if (b.tempo == 0f) minOf(abs(d), abs(d - 1f), abs(d + 1f)) else abs(d)
        r[0] = 1f - m / 0.25f

        var dot = 0f; var na = 0f; var nb = 0f
        for (i in 0 until 12) {
            dot += s.f.chroma[i] * c.f.chroma[i]
            na += s.f.chroma[i].pow(2); nb += c.f.chroma[i].pow(2)
        }
        r[1] = (dot / sqrt(max(na * nb, 1e-12f)) - 0.5f) / 0.5f

        r[2] = 1f - abs(z(c.f.energy, sE) - (z(s.f.energy, sE) + b.energy)) / 2f
        r[3] = 1f - abs(z(c.f.brightness, sB) - (z(s.f.brightness, sB) + b.bright)) / 2f
        r[4] = 1f - abs(z(c.f.rhythm, sR) - z(s.f.rhythm, sR)) / 2f

        val a = tz[s.id]; val z2 = tz[c.id]
        if (a != null && z2 != null) {
            var cd = 0f
            for (i in 0 until dims) cd += a[i] * z2[i]
            r[5] = (cd + 1f) / 2f
        }

        val ea = ez[s.id]; val eb = ez[c.id]
        if (ea != null && eb != null) {
            var e = 0f
            for (i in 0 until edim) e += ea[i] * eb[i]
            r[6] = (e + 1f) / 2f
        }
        for (i in 0 until 7) if (!r[i].isNaN()) r[i] = r[i].coerceIn(0f, 1f)
        return r
    }

    private fun sim(s: Track, c: Track, w: Weights, b: Bias): Float {
        val p = parts(s, c, b)
        val ws = floatArrayOf(w.tempo, w.key, w.energy, w.bright, w.rhythm, w.timbre, w.vibe)
        var num = 0f; var den = 0f
        for (i in 0 until 7) if (!p[i].isNaN()) { num += ws[i] * p[i]; den += ws[i] }
        return if (den <= 0f) 0f else num / den
    }

    /**
     * Learn from feedback: if you LIKE a track, features where it closely matches your seeds get more weight
     * (and features where it differs a lot get less). If you DISLIKE a track that matched the seeds on a
     * feature, that feature is probably not what you care about, so its weight drops.
     * Weights you set to 0 stay 0.
     */
    fun adapt(w: Weights, seeds: List<Track>, c: Track, liked: Boolean, b: Bias): Weights {
        val sum = FloatArray(7)
        val n = IntArray(7)
        for (s in seeds) {
            val p = parts(s, c, b)
            for (i in 0 until 7) if (!p[i].isNaN()) { sum[i] += p[i]; n[i]++ }
        }
        fun f(i: Int, cur: Float): Float {
            if (cur == 0f || n[i] == 0) return cur
            val avg = sum[i] / n[i]
            val mul = if (liked) {
                if (avg > 0.7f) 1.15f else if (avg < 0.3f) 0.9f else 1f
            } else {
                if (avg > 0.7f) 0.87f else 1f
            }
            return (cur * mul).coerceIn(0.1f, 3f)
        }
        return w.copy(
            tempo = f(0, w.tempo), key = f(1, w.key), energy = f(2, w.energy),
            bright = f(3, w.bright), rhythm = f(4, w.rhythm),
            timbre = f(5, w.timbre), vibe = f(6, w.vibe)
        )
    }

    fun rank(
        seeds: List<Track>, liked: List<Track>, disliked: List<Track>,
        w: Weights, b: Bias
    ): List<Pair<Track, Float>> {
        if (all.isEmpty() || seeds.isEmpty()) return emptyList()
        val pos = seeds + liked
        val excluded = (seeds + disliked).map { it.id }.toSet()
        return all.filter { it.id !in excluded }.map { c ->
            val refs = pos.filter { it.id != c.id }
            val p = if (refs.isEmpty()) 0f else refs.map { sim(it, c, w, b) }.average().toFloat()
            val neg = disliked.filter { it.id != c.id }
            val nn = if (neg.isEmpty()) 0f else neg.map { sim(it, c, w, Bias()) }.average().toFloat()
            c to (p - 0.5f * nn)
        }.sortedByDescending { it.second }
    }
}
