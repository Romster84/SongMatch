package com.example.songmatch

import android.app.Application
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class MainVM(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val cacheFile = File(ctx.filesDir, "online.json")

    /** The songs the user uploaded (reference tracks). */
    val uploads = mutableStateListOf<Track>()
    val liked = mutableStateListOf<Long>()
    val disliked = mutableStateListOf<Long>()
    val excludedKeys = mutableStateListOf<String>()
    val bannedMoods = mutableStateListOf<String>()

    private val online = ConcurrentHashMap<Long, Track>()   // analyzed Deezer previews, key = -deezerId
    private var pool: List<Track> = emptyList()

    var weights by mutableStateOf(Weights())
    var bias by mutableStateOf(Bias())
    var results by mutableStateOf<List<Pair<Track, Float>>>(emptyList())
    var showResults by mutableStateOf(false)
    var analyzing by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var playingId by mutableStateOf<Long?>(null)

    private var onlineJob: Job? = null
    private var player: MediaPlayer? = null

    init {
        Embedder.init(ctx)
        Store.load(cacheFile).forEach { online[it.id] = it }
        status = if (Embedder.available) "" else "(مدل هوش مصنوعی پیدا نشد؛ yamnet.tflite را در assets بگذار)"
    }

    // ---------- uploads ----------
    private fun displayName(u: Uri): String {
        val n = try {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Throwable) {
            null
        }
        return n ?: "آهنگ"
    }

    private fun readMeta(u: Uri): Triple<String, String, Long> {
        var title = ""
        var artist = ""
        var dur = 0L
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(ctx, u)
            title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
            artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
        } catch (_: Throwable) {
        }
        if (title.isBlank()) title = displayName(u).substringBeforeLast('.')
        return Triple(title, artist, dur)
    }

    fun addUploads(uris: List<Uri>) {
        if (uris.isEmpty() || analyzing) return
        analyzing = true
        viewModelScope.launch(Dispatchers.Default) {
            var ok = 0
            var failed = 0
            for ((i, u) in uris.withIndex()) {
                status = "در حال آنالیز آهنگ ${i + 1} از ${uris.size}..."
                val id = (u.toString().hashCode().toLong() and 0x7fffffffL) + 1L
                if (withContext(Dispatchers.Main) { uploads.any { it.id == id } }) continue
                val f = try {
                    Analyzer.decode(ctx, u)?.let { Analyzer.analyze(it.first, it.second) }
                } catch (e: Throwable) {
                    null
                }
                if (f == null) { failed++; continue }
                val (title, artist, dur) = readMeta(u)
                withContext(Dispatchers.Main) { uploads.add(Track(id, title, artist, u.toString(), dur, f)) }
                ok++
            }
            status = "$ok آهنگ اضافه شد" + if (failed > 0) " ($failed فایل خوانده نشد)" else ""
            analyzing = false
        }
    }

    fun removeUpload(id: Long) { uploads.removeAll { it.id == id } }

    // ---------- online analysis ----------
    private fun analyzeRemote(d: DTrack): Track? {
        val key = -d.id
        online[key]?.takeIf { !Embedder.available || it.f.embed.isNotEmpty() }?.let { return it }
        val f = File(ctx.cacheDir, "p_${d.id}.mp3")
        return try {
            if (!Deezer.download(d.preview, f)) return null
            val feats = Analyzer.decode(ctx, Uri.fromFile(f))
                ?.let { Analyzer.analyze(it.first, it.second) } ?: return null
            Track(key, d.title, d.artist, "", 30_000, feats, true).also { online[key] = it }
        } catch (e: Throwable) {
            null
        } finally {
            f.delete()
        }
    }

    fun findOnline() {
        if (busy || uploads.isEmpty()) return
        liked.clear(); disliked.clear()
        results = emptyList()
        pool = emptyList()
        showResults = true
        busy = true
        onlineJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val sd = withContext(Dispatchers.Main) { uploads.toList() }
                val exclude = HashSet<Long>()
                val artists = LinkedHashSet<Long>()
                val genres = LinkedHashSet<Int>()

                status = "شناسایی آهنگ‌ها در Deezer..."
                for (s in sd) {
                    ensureActive()
                    val hasArtist = s.artist.isNotBlank() && !s.artist.contains("unknown", true)
                    val q = if (hasArtist) "${s.artist} ${s.title}" else s.title
                    val h = Deezer.search(q, 1, false).firstOrNull() ?: continue
                    exclude.add(h.id)
                    if (h.artistId != 0L) artists.add(h.artistId)
                    if (h.albumId != 0L) {
                        val g = Deezer.genreOfAlbum(h.albumId)
                        if (g >= 0) genres.add(g)
                    }
                }

                val sources = ArrayList<List<DTrack>>()
                status = "جمع‌آوری ترک‌های هنرمندان مرتبط..."
                for (a in artists) { ensureActive(); sources.add(Deezer.top(a, 20)) }
                val rel = LinkedHashSet<Long>()
                for (a in artists) { ensureActive(); rel.addAll(Deezer.related(a, 8)) }
                rel.removeAll(artists)
                for (r in rel.take(30)) { ensureActive(); sources.add(Deezer.top(r, 6)) }

                status = "جمع‌آوری ترک‌های جدید و پرطرفدار ژانر..."
                val gl = if (genres.isEmpty()) listOf(0) else genres.take(3)
                for (g in gl) {
                    ensureActive()
                    sources.add(Deezer.chart(g, 60))
                    for (al in Deezer.newReleases(g, 8)) { ensureActive(); sources.add(Deezer.albumTracks(al)) }
                }

                // interleave sources so the pool is diverse, cap at 300
                val cands = LinkedHashMap<Long, DTrack>()
                var i = 0
                while (cands.size < 300 && sources.any { i < it.size }) {
                    for (src in sources) if (i < src.size) cands.putIfAbsent(src[i].id, src[i])
                    i++
                }
                val list = cands.values.filter { it.id !in exclude && it.preview.isNotEmpty() }.take(300)
                if (list.isEmpty()) {
                    status = "چیزی از Deezer نیومد (اینترنت را چک کن)"
                    return@launch
                }

                val counter = AtomicInteger(0)
                val sem = Semaphore(4)
                coroutineScope {
                    list.map { d ->
                        async {
                            sem.withPermit { ensureActive(); analyzeRemote(d) }
                            status = "آنالیز ترک‌های کاندید: ${counter.incrementAndGet()} از ${list.size}"
                        }
                    }.awaitAll()
                }
                Store.save(cacheFile, online.values.toList())

                // pool = everything analyzed so far (it grows over time as the cache fills)
                val all = online.values.filter { -it.id !in exclude }
                if (all.isEmpty()) {
                    status = "هیچ ترکی برای مقایسه آماده نشد"
                    return@launch
                }
                withContext(Dispatchers.Main) {
                    pool = all
                    recompute()
                }
                status = "${all.size} ترک بررسی شد"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                status = "خطا: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    fun back() {
        onlineJob?.cancel()
        busy = false
        showResults = false
    }

    // ---------- ranking & feedback ----------
    private fun allTracks(): List<Track> = (pool + uploads).distinctBy { it.id }

    fun recompute() {
        val all = allTracks()
        val eng = Engine(all)
        results = eng.rank(
            uploads.toList(),
            all.filter { it.id in liked },
            all.filter { it.id in disliked },
            weights, bias
        ).filter { (t, _) ->
            t.f.key !in excludedKeys && eng.moodTags(t).none { it in bannedMoods }
        }
    }

    fun setW(w: Weights) { weights = w; recompute() }
    fun setB(b: Bias) { bias = b; recompute() }

    fun like(t: Track) {
        disliked.remove(t.id)
        if (t.id in liked) {
            liked.remove(t.id)
        } else {
            liked.add(t.id)
            weights = Engine(allTracks()).adapt(weights, uploads.toList(), t, true, bias)
        }
        recompute()
    }

    fun dislike(t: Track) {
        liked.remove(t.id)
        if (t.id !in disliked) {
            disliked.add(t.id)
            weights = Engine(allTracks()).adapt(weights, uploads.toList(), t, false, bias)
        }
        recompute()
    }

    fun excludeKey(k: String) { if (k !in excludedKeys) excludedKeys.add(k); recompute() }
    fun unexcludeKey(k: String) { excludedKeys.remove(k); recompute() }
    fun toggleMood(m: String) { if (m in bannedMoods) bannedMoods.remove(m) else bannedMoods.add(m); recompute() }

    fun resetSettings() {
        weights = Weights(); bias = Bias()
        excludedKeys.clear(); bannedMoods.clear()
        recompute()
    }

    // ---------- playback ----------
    fun play(t: Track) {
        if (playingId == t.id) { stopPlayer(); return }
        stopPlayer()
        playingId = t.id
        if (t.online) {
            viewModelScope.launch(Dispatchers.IO) {
                val url = Deezer.track(-t.id)?.preview
                withContext(Dispatchers.Main) {
                    if (!url.isNullOrEmpty() && playingId == t.id) startPlayer(Uri.parse(url)) else stopPlayer()
                }
            }
        } else {
            startPlayer(Uri.parse(t.uri))
        }
    }

    private fun startPlayer(uri: Uri) {
        try {
            player = MediaPlayer().apply {
                setDataSource(ctx, uri)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { stopPlayer() }
                setOnErrorListener { _, _, _ -> stopPlayer(); true }
                prepareAsync()
            }
        } catch (e: Exception) {
            stopPlayer()
        }
    }

    private fun stopPlayer() {
        player?.release()
        player = null
        playingId = null
    }

    override fun onCleared() { stopPlayer() }
}
