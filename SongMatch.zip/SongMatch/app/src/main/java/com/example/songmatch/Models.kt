package com.example.songmatch

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

class Features(
    val bpm: Float,
    val energy: Float,
    val dynamics: Float,
    val brightness: Float,
    val rhythm: Float,
    val chroma: FloatArray,   // 12 pitch classes, sums to 1
    val timbre: FloatArray,   // 20 log-mel band means
    val key: String,
    val embed: FloatArray = FloatArray(0)   // neural embedding (empty if no model)
)

class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: String,
    val durationMs: Long,
    val f: Features,
    val online: Boolean = false
)

data class Weights(
    val tempo: Float = 1f,
    val key: Float = 1f,
    val energy: Float = 1f,
    val bright: Float = 1f,
    val timbre: Float = 1f,
    val rhythm: Float = 0.5f,
    val vibe: Float = 2f
)

/** -1..1 : shift the target relative to the seed tracks (0 = same as seeds). */
data class Bias(
    val tempo: Float = 0f,
    val energy: Float = 0f,
    val bright: Float = 0f
)

object Store {
    fun save(file: File, list: List<Track>) {
        val arr = JSONArray()
        for (t in list) {
            val x = t.f
            arr.put(JSONObject().apply {
                put("id", t.id); put("title", t.title); put("artist", t.artist)
                put("uri", t.uri); put("dur", t.durationMs); put("online", t.online)
                put("bpm", x.bpm.toDouble()); put("energy", x.energy.toDouble())
                put("dyn", x.dynamics.toDouble()); put("bright", x.brightness.toDouble())
                put("rhythm", x.rhythm.toDouble()); put("key", x.key)
                put("chroma", JSONArray(x.chroma.map { it.toDouble() }))
                put("timbre", JSONArray(x.timbre.map { it.toDouble() }))
                put("embed", JSONArray(x.embed.map { (it * 10000).roundToInt() / 10000.0 }))
            })
        }
        file.writeText(arr.toString())
    }

    fun load(file: File): List<Track> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                fun fa(name: String): FloatArray {
                    val a = o.getJSONArray(name)
                    return FloatArray(a.length()) { a.getDouble(it).toFloat() }
                }
                Track(
                    o.getLong("id"), o.getString("title"), o.getString("artist"),
                    o.getString("uri"), o.getLong("dur"),
                    Features(
                        o.getDouble("bpm").toFloat(), o.getDouble("energy").toFloat(),
                        o.getDouble("dyn").toFloat(), o.getDouble("bright").toFloat(),
                        o.getDouble("rhythm").toFloat(), fa("chroma"), fa("timbre"),
                        o.getString("key"),
                        if (o.has("embed")) fa("embed") else FloatArray(0)
                    ),
                    o.optBoolean("online", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
