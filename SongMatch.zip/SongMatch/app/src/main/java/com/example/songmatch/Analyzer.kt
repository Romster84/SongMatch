package com.example.songmatch

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.*

/** Pure-Kotlin audio analysis: decodes ~45s of a track and extracts tempo, key, energy, timbre... */
object Analyzer {
    private const val N = 2048
    private const val HOP = 1024
    private const val MELS = 20

    private val MAJOR = floatArrayOf(6.35f, 2.23f, 3.48f, 2.33f, 4.38f, 4.09f, 2.52f, 5.19f, 2.39f, 3.66f, 2.29f, 2.88f)
    private val MINOR = floatArrayOf(6.33f, 2.68f, 3.52f, 5.38f, 2.60f, 3.53f, 2.54f, 4.75f, 3.98f, 2.69f, 3.34f, 3.17f)
    private val NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    /** Returns mono PCM floats and the sample rate, or null if the file can't be decoded. */
    fun decode(ctx: Context, uri: Uri, seconds: Int = 45): Pair<FloatArray, Int>? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    ex.selectTrack(i); fmt = f; break
                }
            }
            if (fmt == null) return null
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = max(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durUs > 90_000_000L) ex.seekTo(durUs / 3, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val out = FloatArray(sr * seconds)
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && n < out.size && guard++ < 200_000) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    val buf = codec.getOutputBuffer(o)!!
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val frames = sb.remaining() / ch
                    var f = 0
                    while (f < frames && n < out.size) {
                        var s = 0
                        for (c in 0 until ch) s += sb.get()
                        out[n++] = s / (32768f * ch)
                        f++
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    ch = max(1, nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                }
            }
            return if (n >= sr * 8) Pair(out.copyOf(n), sr) else null
        } finally {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            ex.release()
        }
    }

    fun analyze(x: FloatArray, sr: Int): Features {
        val win = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }
        val bins = N / 2
        val hz = sr.toFloat() / N
        val nFrames = (x.size - N) / HOP

        // mel filterbank
        fun mel(f: Float) = 2595f * log10(1f + f / 700f)
        fun inv(m: Float) = 700f * (10f.pow(m / 2595f) - 1f)
        val fmin = 40f
        val fmax = min(8000f, sr / 2f)
        val pts = FloatArray(MELS + 2) { inv(mel(fmin) + (mel(fmax) - mel(fmin)) * it / (MELS + 1)) }
        val melW = Array(MELS) { b ->
            FloatArray(bins) { k ->
                val f = k * hz
                val lo = pts[b]; val c = pts[b + 1]; val hi = pts[b + 2]
                when {
                    f <= lo || f >= hi -> 0f
                    f <= c -> (f - lo) / (c - lo)
                    else -> (hi - f) / (hi - c)
                }
            }
        }
        // pitch-class map
        val pc = IntArray(bins) { -1 }
        for (k in 1 until bins) {
            val f = k * hz
            if (f in 65f..2000f) {
                val midi = (12.0 * ln(f / 440.0) / ln(2.0) + 69.0).roundToInt()
                pc[k] = ((midi % 12) + 12) % 12
            }
        }

        val re = FloatArray(N)
        val im = FloatArray(N)
        val mag = FloatArray(bins)
        val prev = FloatArray(MELS)
        val timbreSum = FloatArray(MELS)
        val chromaSum = FloatArray(12)
        val rms = FloatArray(nFrames)
        val onset = FloatArray(nFrames)
        var centSum = 0.0

        for (t in 0 until nFrames) {
            val off = t * HOP
            var e = 0f
            for (i in 0 until N) {
                val v = x[off + i]
                e += v * v
                re[i] = v * win[i]
                im[i] = 0f
            }
            rms[t] = sqrt(e / N)
            fft(re, im)
            var s = 0f
            var w = 0f
            for (k in 0 until bins) {
                val m = sqrt(re[k] * re[k] + im[k] * im[k])
                mag[k] = m
                s += m
                w += m * k * hz
                if (pc[k] >= 0) chromaSum[pc[k]] += m
            }
            centSum += if (s > 1e-9f) w / s else 0f
            var flux = 0f
            for (b in 0 until MELS) {
                var a = 0f
                val wt = melW[b]
                for (k in 0 until bins) a += wt[k] * mag[k]
                val l = ln(1f + a)
                timbreSum[b] += l
                val d = l - prev[b]
                if (d > 0f && t > 0) flux += d
                prev[b] = l
            }
            onset[t] = flux
        }

        // ---- tempo (autocorrelation of onset envelope) ----
        val fps = sr.toFloat() / HOP
        val mean = onset.average().toFloat()
        val o = FloatArray(nFrames) { onset[it] - mean }
        var var0 = 1e-9f
        for (v in o) var0 += v * v
        var0 /= nFrames
        val minLag = max(2, (fps * 60f / 180f).toInt())
        val maxLag = min(nFrames / 2, (fps * 60f / 60f).toInt())
        val ac = FloatArray(maxLag + 2)
        for (lag in minLag..maxLag) {
            var s = 0f
            for (i in 0 until nFrames - lag) s += o[i] * o[i + lag]
            ac[lag] = s / (nFrames - lag)
        }
        var bestLag = minLag
        var bestScore = -Float.MAX_VALUE
        for (lag in minLag..maxLag) {
            val bpm = 60f * fps / lag
            val prior = exp(-0.5f * (log2(bpm / 120f) / 0.8f).pow(2))
            val sc = ac[lag] * prior
            if (sc > bestScore) { bestScore = sc; bestLag = lag }
        }
        var lagRef = bestLag.toFloat()
        if (bestLag in (minLag + 1) until maxLag) {
            val y0 = ac[bestLag - 1]; val y1 = ac[bestLag]; val y2 = ac[bestLag + 1]
            val den = y0 - 2 * y1 + y2
            if (abs(den) > 1e-12f) lagRef += (0.5f * (y0 - y2) / den).coerceIn(-0.5f, 0.5f)
        }
        val bpm = 60f * fps / lagRef
        val rhythm = (ac[bestLag] / var0).coerceIn(0f, 1f)

        // ---- key ----
        var cs = 0f
        for (v in chromaSum) cs += v
        val chroma = FloatArray(12) { chromaSum[it] / max(cs, 1e-9f) }
        var bestC = -2f
        var bestName = "C"
        for (tonic in 0 until 12) {
            val rot = FloatArray(12) { chroma[(it + tonic) % 12] }
            for (mode in 0..1) {
                val c = pearson(rot, if (mode == 0) MAJOR else MINOR)
                if (c > bestC) { bestC = c; bestName = NAMES[tonic] + if (mode == 0) " maj" else " min" }
            }
        }

        // ---- loudness / brightness / dynamics ----
        val meanRms = rms.average().toFloat()
        var sd = 0f
        for (v in rms) sd += (v - meanRms).pow(2)
        sd = sqrt(sd / nFrames)

        return Features(
            bpm = bpm,
            energy = ln(meanRms + 1e-4f),
            dynamics = sd / max(meanRms, 1e-6f),
            brightness = ln(max((centSum / nFrames).toFloat(), 1f)),
            rhythm = rhythm,
            chroma = chroma,
            timbre = FloatArray(MELS) { timbreSum[it] / nFrames },
            key = bestName,
            embed = Embedder.embed(x, sr)
        )
    }

    private fun pearson(a: FloatArray, b: FloatArray): Float {
        val ma = a.average().toFloat(); val mb = b.average().toFloat()
        var num = 0f; var da = 0f; var db = 0f
        for (i in a.indices) {
            val x = a[i] - ma; val y = b[i] - mb
            num += x * y; da += x * x; db += y * y
        }
        return num / sqrt(max(da * db, 1e-12f))
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val t = re[i]; re[i] = re[j]; re[j] = t
                val u = im[i]; im[i] = im[j]; im[j] = u
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = (re[b] * cr - im[b] * ci).toFloat()
                    val ti = (re[b] * ci + im[b] * cr).toFloat()
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
