package com.example.songmatch

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App(vm: MainVM = viewModel()) {
    if (vm.showResults) ResultsScreen(vm) else HomeScreen(vm)
}

@Composable
fun HomeScreen(vm: MainVM) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addUploads(uris)
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        Text("آهنگ‌یاب", style = MaterialTheme.typography.headlineSmall)
        Text(
            "آهنگ(های) خودت را آپلود کن؛ در Deezer دنبال ترک‌های مشابه (جدید و پرطرفدار) می‌گردم.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 6.dp)
        )
        Button(enabled = !vm.analyzing, onClick = { picker.launch(arrayOf("audio/*")) }) {
            Text("آپلود آهنگ")
        }
        Text(vm.status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(vm.uploads, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1)
                        Text(
                            "${t.artist}  |  ${t.f.bpm.roundToInt()} BPM  |  ${t.f.key}",
                            style = MaterialTheme.typography.bodySmall, maxLines = 1
                        )
                    }
                    TextButton(onClick = { vm.play(t) }) { Text(if (vm.playingId == t.id) "■" else "▶") }
                    TextButton(onClick = { vm.removeUpload(t.id) }) { Text("حذف") }
                }
                HorizontalDivider()
            }
        }
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = vm.uploads.isNotEmpty() && !vm.analyzing && !vm.busy,
            onClick = { vm.findOnline() }
        ) { Text("پیدا کردن آهنگ‌های مشابه (${vm.uploads.size})") }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun ResultsScreen(vm: MainVM) {
    BackHandler { vm.back() }
    val ctx = LocalContext.current
    var panel by remember { mutableStateOf(false) }
    val w = vm.weights
    val b = vm.bias
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("بازگشت") }
            Text("آهنگ‌های مشابه", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { panel = !panel }) { Text(if (panel) "بستن تنظیمات" else "تنظیمات") }
        }
        if (vm.busy) {
            Text(vm.status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 6.dp))
        }
        if (panel) {
            LazyColumn(Modifier.weight(1f)) {
                item {
                    Text("اهمیت هر ویژگی (۰ = نادیده بگیر)", style = MaterialTheme.typography.titleSmall)
                    LabeledSlider("تمپو", w.tempo, 0f..2f) { vm.setW(w.copy(tempo = it)) }
                    LabeledSlider("کلید و هارمونی", w.key, 0f..2f) { vm.setW(w.copy(key = it)) }
                    LabeledSlider("انرژی", w.energy, 0f..2f) { vm.setW(w.copy(energy = it)) }
                    LabeledSlider("روشنی صدا", w.bright, 0f..2f) { vm.setW(w.copy(bright = it)) }
                    LabeledSlider("حال‌وهوا و مود (مدل هوش مصنوعی)", w.vibe, 0f..3f) { vm.setW(w.copy(vibe = it)) }
                    LabeledSlider("بافت صدا", w.timbre, 0f..2f) { vm.setW(w.copy(timbre = it)) }
                    LabeledSlider("ریتم‌محوری", w.rhythm, 0f..2f) { vm.setW(w.copy(rhythm = it)) }
                    Text("(با 👍 و 👎 این وزن‌ها خودکار تنظیم می‌شوند)", style = MaterialTheme.typography.bodySmall)

                    Text("جهت نسبت به آهنگ مرجع", style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp))
                    LabeledSlider("تمپو: کندتر  ←  تندتر", b.tempo, -1f..1f) { vm.setB(b.copy(tempo = it)) }
                    LabeledSlider("انرژی: آرام‌تر  ←  پرانرژی‌تر", b.energy, -1f..1f) { vm.setB(b.copy(energy = it)) }
                    LabeledSlider("صدا: تیره‌تر  ←  روشن‌تر", b.bright, -1f..1f) { vm.setB(b.copy(bright = it)) }

                    Text("ممنوع کردن حال‌وهوا (تخمینی)", style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp))
                    Engine.MOODS.forEach { m ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.toggleMood(m) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = m in vm.bannedMoods, onCheckedChange = { vm.toggleMood(m) })
                            Text(m)
                        }
                    }

                    if (vm.excludedKeys.isNotEmpty()) {
                        Text("کلیدهای حذف‌شده", style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(top = 8.dp))
                        vm.excludedKeys.toList().forEach { k ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(k, Modifier.weight(1f))
                                TextButton(onClick = { vm.unexcludeKey(k) }) { Text("برگردان") }
                            }
                        }
                    }
                    OutlinedButton(onClick = { vm.resetSettings() }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("بازنشانی همه")
                    }
                }
            }
        } else {
            if (vm.results.isEmpty() && !vm.busy) {
                Text(vm.status, modifier = Modifier.padding(8.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                items(vm.results.take(100), key = { it.first.id }) { (t, s) ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text(t.title, maxLines = 1)
                        Text(
                            "${t.artist}  |  ${(s.coerceIn(0f, 1f) * 100).roundToInt()}٪  |  ${t.f.bpm.roundToInt()} BPM  |  ${t.f.key}",
                            style = MaterialTheme.typography.bodySmall, maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { vm.play(t) }) { Text(if (vm.playingId == t.id) "■" else "▶") }
                            TextButton(onClick = {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.deezer.com/track/${-t.id}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }) { Text("باز کردن") }
                            TextButton(onClick = { vm.like(t) }) { Text(if (t.id in vm.liked) "👍✓" else "👍") }
                            TextButton(onClick = { vm.dislike(t) }) { Text("👎") }
                            TextButton(onClick = { vm.excludeKey(t.f.key) }) { Text("🚫 ${t.f.key}") }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
