package com.example.songmatch

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class DTrack(
    val id: Long, val title: String, val artist: String,
    val artistId: Long, val preview: String, val albumId: Long = 0L
)

/** Minimal client for Deezer's public API (no key needed; ~30 s MP3 previews). */
object Deezer {
    private const val BASE = "https://api.deezer.com"
    private var last = 0L

    private fun get(path: String): JSONObject? {
        synchronized(this) { // gentle throttle (~8 req/s)
            val wait = 120 - (System.currentTimeMillis() - last)
            if (wait > 0) Thread.sleep(wait)
            last = System.currentTimeMillis()
        }
        return try {
            val c = URL(BASE + path).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "SongMatch/1.0")
            val j = c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            if (j.has("error")) null else j
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(o: JSONObject): DTrack {
        val a = o.optJSONObject("artist")
        val al = o.optJSONObject("album")
        return DTrack(
            o.optLong("id"), o.optString("title"),
            a?.optString("name") ?: "", a?.optLong("id") ?: 0L,
            o.optString("preview"), al?.optLong("id") ?: 0L
        )
    }

    private fun list(j: JSONObject?): List<DTrack> {
        val arr = j?.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).map { parse(arr.getJSONObject(it)) }
    }

    fun search(q: String, limit: Int = 15, requirePreview: Boolean = true): List<DTrack> {
        val r = list(get("/search?q=${URLEncoder.encode(q, "UTF-8")}&limit=$limit"))
        return if (requirePreview) r.filter { it.preview.isNotEmpty() } else r
    }

    fun top(artistId: Long, limit: Int): List<DTrack> =
        list(get("/artist/$artistId/top?limit=$limit")).filter { it.preview.isNotEmpty() }

    fun related(artistId: Long, limit: Int): List<Long> {
        val arr = get("/artist/$artistId/related?limit=$limit")?.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it).optLong("id") }.filter { it != 0L }
    }

    /** Deezer genre id of an album, or -1 if unknown. */
    fun genreOfAlbum(albumId: Long): Int = get("/album/$albumId")?.optInt("genre_id", -1) ?: -1

    /** Current top tracks of a genre (genreId 0 = all genres). */
    fun chart(genreId: Int, limit: Int): List<DTrack> =
        list(get("/chart/$genreId/tracks?limit=$limit")).filter { it.preview.isNotEmpty() }

    /** Newest album releases curated by Deezer editors for a genre. */
    fun newReleases(genreId: Int, limit: Int): List<Long> {
        val arr = get("/editorial/$genreId/releases?limit=$limit")?.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it).optLong("id") }.filter { it != 0L }
    }

    fun albumTracks(albumId: Long): List<DTrack> =
        list(get("/album/$albumId/tracks?limit=15")).filter { it.preview.isNotEmpty() }

    /** Preview URLs expire, so fetch a fresh one right before playing. */
    fun track(id: Long): DTrack? = get("/track/$id")?.let { parse(it) }

    fun download(url: String, dest: File): Boolean = try {
        URL(url).openStream().use { i -> dest.outputStream().use { i.copyTo(it) } }
        dest.length() > 10_000
    } catch (e: Exception) {
        false
    }
}
