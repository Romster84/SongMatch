# SongMatch (آهنگ‌یاب)

Upload your own songs -> the app finds similar, current tracks on Deezer.

## Flow
1. "آپلود آهنگ": pick one or more audio files. Each is analyzed on the phone (tempo, key, energy, brightness,
   timbre, rhythm and, if yamnet.tflite is present, a neural "vibe" embedding). Title/artist come from the file tags.
2. "پیدا کردن آهنگ‌های مشابه": each upload is identified on Deezer, then a candidate pool (<=300) is collected from
   the same artists, related artists, the genre's CURRENT chart and Deezer's NEW RELEASES for that genre.
   Each candidate's 30 s preview is downloaded and analyzed on-device; everything is ranked against your uploads.
   Analyzed candidates are cached (online.json), so the pool grows and later searches get faster.
3. Results: sliders for feature weights and "more/less than seed" direction, 👍/👎 (re-ranks AND learns weights),
   "🚫 <key>" excludes that musical key, mood checkboxes ban heuristic moods (high-energy, calm, happy, sad, dark, acoustic),
   ▶ plays the 30 s preview, "باز کردن" opens the track on Deezer.

## Neural vibe embedding (optional, YAMNet TFLite)
Save a YAMNet TFLite model as `app/src/main/assets/yamnet.tflite` (Kaggle Models: google/yamnet, TFLite variant).
Without it the app uses hand-crafted features only.

## Limits
- Candidates come from Deezer charts/new releases/artist graph, not the entire catalog (no free API offers that).
- Mood tags are rough heuristics, not a trained mood model. Ranking uses 30 s previews.
